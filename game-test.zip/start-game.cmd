@echo off
cd /d "%~dp0"
node start-game.cjs
pause
