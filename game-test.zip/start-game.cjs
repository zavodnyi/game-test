const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const root = path.join(__dirname, 'dist');
const mime = {'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json','.png':'image/png','.webp':'image/webp','.svg':'image/svg+xml','.woff':'font/woff','.woff2':'font/woff2','.txt':'text/plain; charset=utf-8'};
const firstPort = Number(process.env.FIGHT_CLUB_PORT || 5173);
let port = firstPort;
const server = http.createServer((request, response) => {
  let file;
  try {
    const url = new URL(request.url, 'http://localhost');
    file = path.resolve(root, '.' + decodeURIComponent(url.pathname));
    if (file !== root && !file.startsWith(root + path.sep)) { response.writeHead(403); response.end(); return; }
    if (fs.statSync(file).isDirectory()) file = path.join(file, 'index.html');
    if (!fs.statSync(file).isFile()) throw new Error('Not a file');
  } catch { response.writeHead(404); response.end('Not found'); return; }
  response.writeHead(200, {'Content-Type':mime[path.extname(file)] || 'application/octet-stream', 'Cache-Control':'no-cache'});
  if (request.method === 'HEAD') { response.end(); return; }
  fs.createReadStream(file).on('error', () => response.destroy()).pipe(response);
});
server.on('error', error => {
  if (error.code === 'EADDRINUSE' && port < firstPort + 10) { port++; server.listen(port, '127.0.0.1'); }
  else { console.error(error.message); process.exitCode = 1; }
});
server.on('listening', () => {
  console.log(`DVOR - open in your browser: http://127.0.0.1:${port}/`);
  console.log('Keep this window open while playing. Ctrl+C stops the game server.');
});
server.listen(port, '127.0.0.1');
